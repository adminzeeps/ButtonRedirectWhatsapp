![Texto alternativo](https://zeeps.com.br/assets/img/logo.png)

## Dicas para Implmentar script
---

Colocoque o script no seu site:
 --> <script src="Caminho/floating_button.js"></script>
 --> Insira o Script floating_button.js

---
Colocoque o script no seu site:
 --> se for usar cdn colocar o script no header da aplicação.

## OBSERVAÇÃO NÃO ESQUECER DE ALTERAR O NUMERO EM SEU_NUMERO_DE_TELEFONE